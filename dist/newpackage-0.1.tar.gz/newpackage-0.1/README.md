#newpackage

## building this package locally

## installing this package from github
'pip install git +https://github.com/mphoscallos/newpackage.git'

## updating this package from github
'pip install --upgrade git+https://github.com/mphoscallos/newpackage.git'
