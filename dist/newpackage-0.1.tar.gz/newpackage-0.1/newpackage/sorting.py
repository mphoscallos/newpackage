def bubble_sort(items):

    '''Return array of items, sorted in ascending order'''
def merge_sort(items):

    '''Return array of items, sorted in ascending order'''
def quick_sort(items):

    '''Return array of items, sorted in ascending order'''
